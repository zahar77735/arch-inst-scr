#!/bin/sh

sudo pacman -U exo-devel-4.15.2-1-x86_64.pkg.tar.zst xfce4-dev-tools-devel-4.15.0-1-x86_64.pkg.tar.zst garcon-devel-0.7.1-2-x86_64.pkg.tar.zst xfce4-panel-devel-4.15.4-2-x86_64.pkg.tar.zst libxfce4ui-devel-4.15.3-3-x86_64.pkg.tar.zst xfce4-power-manager-devel-1.7.0-1-x86_64.pkg.tar.zst libxfce4util-devel-4.15.3-1-x86_64.pkg.tar.zst xfce4-session-devel-4.15.0-1-x86_64.pkg.tar.zst thunar-devel-4.15.2-1-x86_64.pkg.tar.zst xfce4-settings-devel-4.15.2-1-x86_64.pkg.tar.zst thunar-volman-devel-1:4.15.0-1-x86_64.pkg.tar.zst xfconf-devel-4.15.0-1-x86_64.pkg.tar.zst tumbler-devel-0.3.0-1-x86_64.pkg.tar.zst xfdesktop-devel-4.15.0-1-x86_64.pkg.tar.zst xfce4-appfinder-devel-4.15.1-2-x86_64.pkg.tar.zst xfwm4-devel-4.15.1-1-x86_64.pkg.tar.zst xfce4-devel-meta-4.15-1-any.pkg.tar.zst

